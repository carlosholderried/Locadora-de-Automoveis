package clientes;

import alugueis.Alugueis;

public class Clientes extends Alugueis {
		
	protected String nome;
	protected String placaAlugado;
	
	public Clientes(String nome, String placaAlugado)
	{
		this.nome = nome;
		this.placaAlugado = placaAlugado;
	}

	public String getNome(){
		return nome;
	}

	public void setNome(String nome){
		this.nome = nome;
	}


	public String toString()
	{
			return "Nome: " + nome + "\ncpfClientes: " + Alugueis.getCpf();	//da para testar o armazenamento da string por aqui
	}	
	
}
