package automoveis;

public class Medios extends Automoveis{


	public Medios(String placaAuto, String cpf) {
		super(placaAuto, cpf);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
}
