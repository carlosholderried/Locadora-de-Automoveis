package automoveis;

public class Populares extends Automoveis{


	public Populares(String placaAuto, String cpf) {
		super(placaAuto, cpf);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
}
