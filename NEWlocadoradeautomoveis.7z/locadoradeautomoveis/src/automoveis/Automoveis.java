package automoveis;

import alugueis.Alugueis;

public class Automoveis extends Alugueis{
	
	protected String placaAuto;
	protected String tipo;
	protected double ano;	
	protected double valordiaria;
	protected int vago;
	protected String devolucao; 
		
	public Automoveis(String placaAuto, String cpf){
		super(placaAuto, cpf);
		// TODO Auto-generated constructor stub
	}
	/*
	public int carroVago(){
		return vago;
	} */
	
	public String getplacaAuto(){		
		return placaAuto;
	}
	
	public void setplacaAuto(String placaAuto){
		this.placaAuto = placaAuto;
	}	
	
	
	public String getTipo() {
		return tipo;
	}
	
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}	
		
	
	public double getAno() {		
		return ano;
	}
	
	public void setAno(double ano) {
		this.ano = ano;
	}	
		
	
	public double getValordiaria() {
		return valordiaria;
	}
	
	public void setValordiaria(double valordiaria) {
		this.valordiaria = valordiaria;
	}

	
	public int  getVago() {
		return vago;
	}
	
	public void setVago(int vago) {
		this.vago = vago; 
	}
	
	
	public String getDevolucao() {
		return tipo;
	}
	public void setDevolucao(String devolucao) {
		this.devolucao = devolucao;
	}
		
	
	public String toString()
	{
			return "placaAuto: " + placaAuto + " Tipo: " + tipo + " Ano: " + ano + " Valor da diaria: " + valordiaria;	//da para testar o armazenamento da string por aqui
	}
	
	
}
