package alugueis;

public class Alugueis {
	protected String cpf;
	protected String placa;
	
	public Alugueis(String cpf, String placa){   
		this.cpf = cpf;
		this.placa = placa;		
	}
	
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	
	}
	
	
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	
	}
	
	
	public String toString()
	{
			return "";
	}
	
	
}