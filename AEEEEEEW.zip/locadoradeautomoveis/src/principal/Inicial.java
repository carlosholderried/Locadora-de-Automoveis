package principal;

import visualizacao.Interface;

public class Inicial {

	public static void main(String[] args) {

		Interface interUsuario;
		interUsuario = new Interface();
		
		interUsuario.menuPrincipal();

	}

}