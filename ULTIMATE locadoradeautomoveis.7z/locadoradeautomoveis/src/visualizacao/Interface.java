package visualizacao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
import clientes.Clientes;
import automoveis.Automoveis;
import automoveis.Grandes;
import automoveis.Medios;
import automoveis.Populares;


//falta usar calendar para calcular o desconto no valor da diaria	
//Calendar.getInstance()
public class Interface{
	
	int cont = 0;
	public ArrayList<Automoveis>  auto = new ArrayList<Automoveis>();
	public ArrayList<Clientes>  client = new ArrayList<Clientes>();
	public int proximoLivre = 0;
	int dias = 0;
	
	Scanner entrada = new Scanner(System.in);
	
	public void menuPrincipal(){	
		
	
		System.out.println("1.Cadastrar Cliente");		
		System.out.println("2.Cadastrar Autom�vel");	
		System.out.println("3.Apresentar Clientes cadastrados");	
		System.out.println("4.Apresentar Automoveis cadastrados");
		System.out.println("5.Alugar um autom�vel");	
		System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
		System.out.println("7.Sair");					
											
		int opcao = entrada.nextInt();
		
		//TESTE \/
				
		String placa = "whatever";	
		
		String tipo = "Grande";
		
		Double ano = 2021.0;
		
		Double valordiaria = 300.0;
		
		int vago = 1;
		
		String devolucao = "0";
		
		Grandes tempGrand = new Grandes(placa, tipo, ano, valordiaria, vago, devolucao);
		
		auto.add(tempGrand);
		
		
		
		
		String placa2 = "ity7134";	
		
		String tipo2 = "Popular";
		
		Double ano2 = 2012.0;
		
		Double valordiaria2 = 100.0;
		
		int vago2 = 1;
		
		String devolucao2 = "0";
		
		Medios tempMed = new Medios(placa2, tipo2, ano2, valordiaria2, vago2, devolucao2);																	
		auto.add(tempMed);
		
		//TESTE /\
			
		while(opcao != 7){	
							switch(opcao){
											case 1:
												    
													System.out.print("Digite o nome do cliente: ");	
													entrada.nextLine();	
													String nome = entrada.nextLine();
													
													System.out.print("Digite o cpf do cliente: ");
													String cpf = entrada.nextLine();																
													
													
													Clientes tempClient = new Clientes(nome,cpf);											
													tempClient.setNome(nome);
													tempClient.setCpf(cpf);														
													client.add(tempClient);		
																								
													break;
																		
											case 2:	/*															
													System.out.println("1.Automovel grande");	
													System.out.println("2.Automovel medio");
													System.out.println("3.Automovel popular");
													int opcao2 = entrada.nextInt();
															switch(opcao2){
																			case 1:
																					System.out.print("Digite a placa do carro: ");
																					entrada.nextLine();
																					String placa = entrada.nextLine();	
																					
																					String tipo = "Grande";
																					
																					System.out.print("Digite o ano do modelo do carro: ");
																					Double ano = entrada.nextDouble();
																					
																					System.out.print("Digite valor base da diaria do carro: ");
																					Double valordiaria = entrada.nextDouble();
																					
																					int vago = 1;
																					String devolucao = "0";
																					
																					Grandes tempGrand = new Grandes(placa, tipo, ano, valordiaria, vago, devolucao);																	
																					auto.add(tempGrand);																	
																					break;			
																			case 2:	
																				  	System.out.print("Digite a placa do carro: ");
																				  	entrada.nextLine();
																					String placa2 = entrada.nextLine();	
																					
																					String tipo2 = "Medio";
																					
																					System.out.print("Digite o ano do modelo do carro: ");
																					Double ano2 = entrada.nextDouble();
																					
																					System.out.print("Digite valor base da diaria do carro: ");
																					Double valordiaria2 = entrada.nextDouble();
																					
																					int vago2 = 1;
																					String devolucao2 = "0";
																					
																					Medios tempMed = new Medios(placa2, tipo2, ano2, valordiaria2, vago2, devolucao2);																	
																					auto.add(tempMed);
																					break;
																		    case 3:
																			    	System.out.print("Digite a placa do carro: ");
																			    	entrada.nextLine();
																					String placa3 = entrada.nextLine();	
																					
																					String tipo3 = "Popular";
																					
																					System.out.print("Digite o ano do modelo do carro: ");
																					Double ano3 = entrada.nextDouble();
																					
																					System.out.print("Digite valor base da diaria do carro: ");
																					Double valordiaria3 = entrada.nextDouble();
																					
																					int vago3 = 1;
																					String devolucao3 = "0";
																					
																					Populares tempPop = new Populares(placa3, tipo3, ano3, valordiaria3, vago3, devolucao3);																	
																					auto.add(tempPop); 
																					break;
																}	*/																											    
														
											case 3:
													for(Clientes clientes : client){				
													System.out.println(clientes.toString());}											
													break;												
											case 4:
													for(Automoveis automoveis : auto){				
													System.out.println(automoveis.toString());}									
													break;											
											case 5:		
													System.out.print("Digite o seu CPF: ");
											    	entrada.nextLine();
													String cpf2 = entrada.nextLine();	
													
													System.out.print("Digite o numero de dias que deseja alugar o carro: ");
													int dias = entrada.nextInt();
													
													LocalDate date = LocalDate.now();
													LocalDate date2  = date.plusDays(dias);
													final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu MMMM dd", Locale.ENGLISH);
											        String devolucao4 = dtf.format(date2);
											        
											        cont = 0;
											        for(Automoveis automoveis : auto){	
													    	  
															if(automoveis.getVago() == 1){
															cont++;
															System.out.println(cont+". " + automoveis.toString()); 
															}																		
													}	
											        cont++;
											        System.out.println(cont+". Sair");
											        
											        int opcao3 = entrada.nextInt();
											        int cont2 = 0;
											        
											     
											        
											        for(Automoveis automoveis : auto){
											        		
											        		int vago4 = 0;
											        		
													      	if(automoveis.getVago() == 1){	cont2++;
													      									
													      	}
													      	
															if(cont2 == opcao3){	
																					automoveis.setVago(vago4);
																					automoveis.setDevolucao(devolucao4);																					
															}
																																
													}
											        
											   
											        
													break;											
											case 6:	
												System.out.print("Digite o seu CPF: ");
										    	entrada.nextLine();
												String cpf3 = entrada.nextLine();
												for(Automoveis automoveis : auto){	
																					
																					LocalDate date3 = LocalDate.now();
																					final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("uuuu MMMM dd", Locale.ENGLISH);
																			        String devolucao5 = dtf2.format(date3);		
																			        String tempdate = "0";
																			        tempdate = automoveis.getDevolucao();
																					if(devolucao5.compareTo(tempdate) > 0){	
																															  //aumentar valor a ser pago
																																							}
												}
													break;		
							}
							
						System.out.println("\n1.Cadastrar Cliente");		
						System.out.println("2.Cadastrar Autom�vel");	
						System.out.println("3.Apresentar Clientes cadastrados");	
						System.out.println("4.Apresentar Automoveis cadastrados");
						System.out.println("5.Alugar um autom�vel");	
						System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
						System.out.println("7.Sair");
						opcao = entrada.nextInt();		
						
		}	
	}	
}