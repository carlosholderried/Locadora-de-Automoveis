package automoveis;

public class Alugados extends Automoveis{
	
	
	public Alugados(String placa, String tipo, double ano, double valordiaria, int vago, String devolucao) {
		super(placa, tipo, ano, valordiaria, vago, devolucao);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
		
}
