package automoveis;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Medios extends Automoveis{

	public Medios(String placa, String tipo, double ano, double valordiaria, int vago,  int dias,int day, int month, int year) {
		super(placa, tipo, ano, valordiaria, vago, dias,day,  month,  year);
		// TODO Auto-generated constructor stub
	}

	LocalDate date = LocalDate.now();
	final DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("uuuu", Locale.ENGLISH);
    String datestr = dtf2.format(date);	
    Integer year = Integer.valueOf(datestr);
 			
    @Override
	public double precoMedio(){  if(year-ano>3){return dias * valordiaria*(1-(0.05*3));
							    }	else{
									   			return dias * valordiaria*(1-(0.05*(year-ano)));
								    } 
	}
	
	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
}
