package principal;
import java.util.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import clientes.Clientes;
import automoveis.Automoveis;
import automoveis.Grandes;
import automoveis.Medios;
import automoveis.Populares;

public class Procedimentos {  //double minusculo o maiusculo?
	
	static int cont = 0;
	public static ArrayList<Automoveis>  auto = new ArrayList<Automoveis>();
	public static ArrayList<Clientes>  client = new ArrayList<Clientes>();
	public int proximoLivre = 0;
	int dias = 0;
	
	static Scanner entrada = new Scanner(System.in);
	
	public static void testa(){
//TESTE \/ 		//////////////////////////////////////////////////////////////////////////////////////////////////////////////

String nome4 = "Carlos";	

String cpf4 = "01733625089";

String placaAlug4 = "0";

Clientes tempClients = new Clientes(nome4, cpf4, placaAlug4);

client.add(tempClients);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
String nome5 = "Bruno";	

String cpf5 = "0000000001";

String placaAlug5 = "0";

Clientes tempClientss = new Clientes(nome5,cpf5, placaAlug5);

client.add(tempClientss);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
String nome6 = "Mateus";	

String cpf6 = "2222222222";

String placaAlug6 = "0";

Clientes tempClientsss = new Clientes(nome6,cpf6,placaAlug6);

client.add(tempClientsss);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
String placa6 = "whatever";	
String tipo6 = "Grande";
Double ano6 = 2021.0;
Double valordiaria6 = 300.0;
int vago6 = 1;
int dias6 = 0;
int day6=1;
int month6=1;
int year6=1990;

Grandes tempGrands = new Grandes(placa6, tipo6, ano6, valordiaria6, vago6, dias6,day6,month6,year6);
auto.add(tempGrands);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

String placa7 = "wtfwtf";	
String tipo7 = "Medio";
Double ano7 = 2015.0;
Double valordiaria7 = 200.0;
int vago7 = 1;
int dias7 = 0;
int day7=1;
int month7=1;
int year7=1990;

Medios tempMeds = new Medios(placa7, tipo7, ano7, valordiaria7, vago7, dias7,day7,month7,year7);																	
auto.add(tempMeds);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

String placa8 = "ity7134"; 
String tipo8 = "Popular";
Double ano8 = 2012.0;
Double valordiaria8 = 100.0;
int vago8 = 1;
int dias8=0;
int day8=1;
int month8=1;
int year8=1990;

Populares tempPops = new Populares(placa8, tipo8, ano8, valordiaria8, vago8, dias8,day8,month8,year8);																	
auto.add(tempPops);

//TESTE /\  	//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	}
	
	static String nome = ".";
	public static void armazenaNome(){		
		entrada.nextLine();	
		nome = entrada.nextLine();				
	}

	public static void armazenaCpf(){		
		String cpf = entrada.nextLine();																		
		String placaAluguel = "0";
		Clientes tempClient = new Clientes(nome,cpf, placaAluguel);											
		tempClient.setNome(nome);
		tempClient.setCpf(cpf);
		tempClient.setPlacaAluguel(placaAluguel);
		client.add(tempClient);				
	}
	
	static String placa = ".";
	public static void armazenaPlacaGrande(){
		entrada.nextLine();
		placa = entrada.nextLine();
	}
	 static int ano = 1990;
	public static void armazenaAnoGrande(){		
		ano = entrada.nextInt();
	}	
	
	public static void armazenaValorBaseGrande(){		
		Double valordiaria = entrada.nextDouble();		
		String tipo = "Grande";
		int vago = 1;
		int dias = 0;
		int day=1;
		int month=1;
		int year=1990;		
		Grandes tempGrand = new Grandes(placa, tipo, ano, valordiaria, vago, dias,day,month,year);																	
		auto.add(tempGrand);
	}
	
	static String placa2 = "."; static String tipo2 = ".";
	public static void armazenaPlacaMedio(){
	  	entrada.nextLine();
		placa2 = entrada.nextLine();	
		
		tipo2 = "Medio";
	}
	
	static double ano2 = 1990;
	public static void armazenaAnoMedio(){
		ano2 = entrada.nextDouble();
	}
	
	public static void armazenaValorBaseMedio(){
		Double valordiaria2 = entrada.nextDouble();
		int vago2=1;
		int dias2=0;
		int day2=1;
		int month2=1;
		int year2=1990;
		
		Medios tempMed = new Medios(placa2, tipo2, ano2, valordiaria2, vago2, dias2,day2,month2,year2);																	
		auto.add(tempMed);
	}
	static String placa3 = "."; static String tipo3 = ".";
	public static void armazenaPlacaPop(){
	entrada.nextLine();
	placa3 = entrada.nextLine();	
	tipo3 = "Popular";
		
	}
	
	static double ano3 = 1990;  
	public static void armazenaAnoPop(){
		ano3 = entrada.nextDouble();
	}
	
	public static void armazenaValorbasePop(){
		Double valordiaria3 = entrada.nextDouble();
		
		int vago3 = 1;
		int dias3 = 0;
		int day3=1;
		int month3=1;
		int year3=1990;
		
		Populares tempPop = new Populares(placa3, tipo3, ano3, valordiaria3, vago3,dias3,day3,month3,year3);																	
		auto.add(tempPop);
	}
	
	public static void apresentaClientes(){
		for(Clientes clientes : client){				
			System.out.println(clientes.toString());}		
	}
	
	public static void apresentaAuto(){
		for(Automoveis automoveis : auto){	
		System.out.println(automoveis.toString());}	
	}	
	
	static String cpf2 = ".";
	public static void alugaCpf(){
		entrada.nextLine();
		cpf2 = entrada.nextLine();			
	}
	
	public static void alugaDias(){
		int dias = entrada.nextInt();
		
		int tempDia = 1;
		int tempMes = 1;
		int tempAno = 1990;
		
		LocalDate date = LocalDate.now();
																												
		tempDia = date.getDayOfMonth();
		tempMes = date.getMonthValue();
		tempAno = date.getYear();
		
        cont = 0;
        for(Automoveis automoveis : auto){	
		    	  
				if(automoveis.getVago() == 1){
				cont++;
				System.out.println(cont+". " + automoveis.toString()); 
				}																		
		}	
        cont++;
        System.out.println(cont+". Sair");
        
        int opcao3 = entrada.nextInt();
        int cont2 = 0;
        
        String placaTemp = "0";
        int vago4 = 0;
        
        for(Automoveis automoveis : auto){											        	
	        	
		      	if(automoveis.getVago() == 1){	cont2++;
		      		
		      	}
		      	
				if(cont2 == opcao3){	
										automoveis.setVago(vago4);
										placaTemp = automoveis.getPlaca();
										automoveis.setDias(dias);
										automoveis.setDay(tempDia);
										automoveis.setMonth(tempMes);
										automoveis.setYear(tempAno);
										break;
										
				}
					
		}
        
        String cpfTemp = "0";
        
        for(Clientes clientes : client){		
        	
        										cpfTemp = clientes.getCpf(); 
        										if(cpf2.equals(cpfTemp)) {
        																clientes.setPlacaAluguel(placaTemp);
        										}
        }
		}
	
	static String tempPlacaAluguel = ".";
	public static void devolucaoCpf(){
		entrada.nextLine();
		String cpf3 = entrada.nextLine();
		
		tempPlacaAluguel = "0";
		
		for(Clientes clientes : client){
			String tempTempCpf = clientes.getCpf(); 
			if(cpf3.equals(tempTempCpf)){
				tempPlacaAluguel = clientes.getPlacaAluguel();
		}}
	}
	
	public static void devolucaoAno(){
		 ano = entrada.nextInt();
		
	}
	
	static int mes = 7;
	public static void devolucaoMes(){
		mes = entrada.nextInt();
	}
	
	static int dia = 7;
	public static void devolucaoDia(){
		dia = entrada.nextInt();
		for(Automoveis automoveis : auto){	
																												
			LocalDate dataRetirada = LocalDate.of(ano, mes, dia);
			LocalDate dataMarcada = LocalDate.of(automoveis.getYear(),automoveis.getMonth(),automoveis.getDay());
	        																										
			long diasDiff = dataMarcada.until(dataRetirada, ChronoUnit.DAYS);
			 
			int tempDias = automoveis.getDias();
			 String tempPlaca3 = automoveis.getPlaca();
			 String tempTipo = automoveis.getTipo();
			 															
			if(diasDiff > Long.valueOf(tempDias) && tempPlacaAluguel.equals(tempPlaca3) && tempTipo.equals("Grande")){
				double valorGran = automoveis.precoGrande() * 1.1;
				System.out.print("\nValor a ser pago: "+ valorGran+"\n");
				automoveis.setVago(1);
				break;
			}
			else {
				if(diasDiff > Long.valueOf(tempDias) && tempPlacaAluguel.equals(tempPlaca3) && tempTipo.equals("Medio")){
					double valorMed = automoveis.precoMedio() * 1.1;
					System.out.print("\nValor a ser pago: "+ valorMed+"\n");
					automoveis.setVago(1);
					break;
				}
				else {
					if(diasDiff > Long.valueOf(tempDias) && tempPlacaAluguel.equals(tempPlaca3) && tempTipo.equals("Popular")){
						double valorPop = automoveis.precoPopular() * 1.1;
						System.out.print("\nValor a ser pago: "+ valorPop+"\n");
						automoveis.setVago(1);
						break;
					}
					else {
						if( tempPlacaAluguel.equals(tempPlaca3) && tempTipo.equals("Grande")){	
							System.out.print("\nValor a ser pago: "+ automoveis.precoGrande()+"\n");
							automoveis.setVago(1);
							break;
					}
					else {
						if( tempPlacaAluguel.equals(tempPlaca3) && tempTipo.equals("Medio")){
							System.out.print("\nValor a ser pago: "+ automoveis.precoMedio()+"\n");
							automoveis.setVago(1);
							break;
						}											
						else {
							if( tempPlacaAluguel.equals(tempPlaca3) && tempTipo.equals("Popular")){
								System.out.print("\nValor a ser pago: "+ automoveis.precoPopular()+"\n");
								automoveis.setVago(1);
								break;
							}}}}}}
		}
	}
	
	
	
}
