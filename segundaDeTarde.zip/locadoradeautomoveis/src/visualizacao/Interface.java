package visualizacao;
import java.util.*;
import principal.Procedimentos;


public class Interface{
	
	Scanner entrada = new Scanner(System.in);
	
	public void menuPrincipal(){	
			
		System.out.println("1.Cadastrar Cliente");		
		System.out.println("2.Cadastrar Autom�vel");	
		System.out.println("3.Apresentar Clientes cadastrados");	
		System.out.println("4.Apresentar Automoveis cadastrados");
		System.out.println("5.alugar um autom�vel");	
		System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
		System.out.println("7.Sair");					
											
		int opcao = entrada.nextInt();
		
		Procedimentos.testa();
		
		while(opcao != 7){	
							switch(opcao){
											case 1:
												    
													System.out.print("Digite o nome do cliente: ");	
													Procedimentos.armazenaNome();
													
													System.out.print("Digite o cpf do cliente: ");
													Procedimentos.armazenaCpf();																										
													break;
																		
											case 2:																
													System.out.println("1.Automovel grande");	
													System.out.println("2.Automovel medio");
													System.out.println("3.Automovel popular");
													int opcao2 = entrada.nextInt();
															switch(opcao2){
																			case 1:
																					System.out.print("Digite a placa do carro: ");
																					Procedimentos.armazenaPlacaGrande();
																					
																					System.out.print("Digite o ano do modelo do carro: ");
																					Procedimentos.armazenaAnoGrande();
																					
																					System.out.print("Digite valor base da diaria do carro: ");
																					Procedimentos.armazenaValorBaseGrande();														
																					break;			
																			case 2:	
																				  	System.out.print("Digite a placa do carro: ");
																				  	Procedimentos.armazenaPlacaMedio();
																				  	
																					System.out.print("Digite o ano do modelo do carro: ");
																					Procedimentos.armazenaAnoMedio();
																					
																					System.out.print("Digite valor base da diaria do carro: ");
																					Procedimentos.armazenaValorBaseMedio();
																					break;
																		    case 3:
																			    	System.out.print("Digite a placa do carro: ");
																			    	Procedimentos.armazenaPlacaPop();
																			    	
																					System.out.print("Digite o ano do modelo do carro: ");
																					Procedimentos.armazenaAnoPop();
																					
																					System.out.print("Digite valor base da diaria do carro: ");
																					Procedimentos.armazenaValorbasePop();
																					break;
																}																												    
														
											case 3:
													Procedimentos.apresentaClientes();
													break;												
											case 4:	
													Procedimentos.apresentaAuto();				
													break;											
											case 5:		
													System.out.print("Digite o seu CPF: ");
											    	Procedimentos.alugaCpf();	
													
													System.out.print("Digite o numero de dias que deseja alugar o carro: ");
													Procedimentos.alugaDias();
													break;											
											case 6:	
												System.out.print("Digite o seu CPF: ");
												Procedimentos.devolucaoCpf();
												
												System.out.print("Digite o ano da devolu��o.");
												Procedimentos.devolucaoAno();
												
												System.out.print("Digite o mes da devolu��o.");
												Procedimentos.devolucaoMes();
												
												System.out.print("Digite o dia da devolu��o.");
												Procedimentos.devolucaoDia();
												break;												
							}
							
						System.out.println("\n1.Cadastrar Cliente");		
						System.out.println("2.Cadastrar Autom�vel");	
						System.out.println("3.Apresentar Clientes cadastrados");	
						System.out.println("4.Apresentar Automoveis cadastrados");
						System.out.println("5.alugar um autom�vel");	
						System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
						System.out.println("7.Sair");
						opcao = entrada.nextInt();		
						
		}	
	}

}