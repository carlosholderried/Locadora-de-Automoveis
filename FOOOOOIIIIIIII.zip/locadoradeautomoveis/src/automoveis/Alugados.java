package automoveis;

public class Alugados extends Automoveis{
	
	
	public Alugados(String placa, String tipo, double ano, double valordiaria, int vago,  int dias,int day, int month, int year) {
		super(placa, tipo, ano, valordiaria, vago, dias,day,  month,  year);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
		
}
