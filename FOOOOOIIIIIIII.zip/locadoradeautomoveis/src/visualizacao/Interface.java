package visualizacao;
import java.util.*;
import principal.Procedimentos;


public class Interface{	
	
	public void menuPrincipal(){	
		
		Scanner entrada = new Scanner(System.in);				
	  	
		Procedimentos pr = new Procedimentos();
		int opcao = 0;
		
 
		
		/*do{
			System.out.println("Digite um double");	
			double testeDouble = entrada.nextDouble();
			System.out.println("Digite uma string");
			String testeString = entrada.nextLine();
		}while(opcao == 0);*/
		
		do{	
			System.out.println("1.Cadastrar Cliente");		
			System.out.println("2.Cadastrar Autom�vel");	
			System.out.println("3.Apresentar Clientes cadastrados");	
			System.out.println("4.Apresentar Automoveis cadastrados");
			System.out.println("5.alugar um autom�vel");	
			System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
			System.out.println("7.Sair");
			opcao = entrada.nextInt();
			entrada.nextLine();
			
							switch(opcao){												
											case 1:	
													System.out.println("Digite o nome do cliente: ");	
													pr.armazenaNome();
													
													System.out.println("Digite o cpf do cliente: ");
													pr.armazenaCpf();																										
													break;
																		
											case 2:																
													System.out.println("1.Automovel grande");	
													System.out.println("2.Automovel medio");
													System.out.println("3.Automovel popular");
													int opcao2 = entrada.nextInt();
													entrada.nextLine();
															switch(opcao2){
																			case 1:
																					System.out.println("Digite a placa do carro: ");
																					pr.armazenaPlacaGrande();
																					
																					System.out.println("Digite o ano do modelo do carro: ");
																					pr.armazenaAnoGrande();
																					
																					System.out.println("Digite valor base da diaria do carro: ");
																					pr.armazenaValorBaseGrande();														
																					break;			
																			case 2:	
																				  	System.out.println("Digite a placa do carro: ");
																				  	pr.armazenaPlacaMedio();
																				  	
																					System.out.println("Digite o ano do modelo do carro: ");
																					pr.armazenaAnoMedio();
																					
																					System.out.println("Digite valor base da diaria do carro: ");
																					pr.armazenaValorBaseMedio();
																					break;
																		    case 3:
																			    	System.out.println("Digite a placa do carro: ");
																			    	pr.armazenaPlacaPop();
																			    	
																					System.out.println("Digite o ano do modelo do carro: ");
																					pr.armazenaAnoPop();
																					
																					System.out.println("Digite valor base da diaria do carro: ");
																					pr.armazenaValorbasePop();
																					break;
																}																												    
														
											case 3:
													pr.apresentaClientes();
													break;												
											case 4:	
													pr.apresentaAuto();				
													break;											
											case 5:		
													System.out.println("Digite o seu CPF: ");
											    	pr.alugaCpf();
											    	
													System.out.println("Digite o numero de dias que deseja alugar o carro: ");
													pr.alugaDias();
													break;											
											case 6:	
												System.out.println("Digite o seu CPF: ");
												pr.devolucaoCpf();
												
												System.out.println("Digite o ano da devolu��o.");
												pr.devolucaoAno();
												
												System.out.println("Digite o mes da devolu��o.");
												pr.devolucaoMes();
												
												System.out.println("Digite o dia da devolu��o.");
												pr.devolucaoDia();
												break;												
							}
							
					/*	System.out.println("\n1.Cadastrar Cliente");		
						System.out.println("2.Cadastrar Autom�vel");	
						System.out.println("3.Apresentar Clientes cadastrados");	
						System.out.println("4.Apresentar Automoveis cadastrados");
						System.out.println("5.alugar um autom�vel");	
						System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
						System.out.println("7.Sair");
						opcao = entrada.nextInt();
						entrada.nextLine();             */
					
		}while(opcao != 7);
		entrada.close();	
	}	
}