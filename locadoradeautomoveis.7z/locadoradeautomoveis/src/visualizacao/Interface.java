package visualizacao;

import java.util.ArrayList;
import java.util.Scanner;
import clientes.Clientes;
import automoveis.Automoveis;
import automoveis.Grandes;
import automoveis.Medios;
import automoveis.Populares;

//falta usar calendar para calcular o desconto no valor da diaria	
//Calendar.getInstance()
public class Interface{
	
	int cont = 0;
	public ArrayList<Automoveis>  prod = new ArrayList<Automoveis>();
	public ArrayList<Clientes>  client = new ArrayList<Clientes>();
	public int proximoLivre = 0;
	
	Scanner entrada = new Scanner(System.in);
	
	public void menuPrincipal(){	
		
	System.out.println("1.Cadastrar Cliente");		
	System.out.println("2.Cadastrar Autom�vel");	
	System.out.println("3.Apresentar Clientes cadastrados");	
	System.out.println("4.Apresentar Automoveis cadastrados");
	System.out.println("5.Alugar um autom�vel");	
	System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
	System.out.println("7.Sair");					
										
int opcao = entrada.nextInt();
		
while(opcao != 7){	
					switch(opcao){
									case 1:
											System.out.print("Digite o nome do cliente: ");	
											entrada.nextLine();	
											String nome = entrada.nextLine();
											
											System.out.print("Digite o cpf do cliente: ");
											String cpf = entrada.nextLine();																
											
											
											Clientes tempClient = new Clientes(nome,cpf);											
											tempClient.setNome(nome);
											tempClient.setCpf(cpf);														
											client.add(tempClient);		
																						
											break;
									
									case 2:																
											System.out.println("1.Automovel grande");	
											System.out.println("2.Automovel medio");
											System.out.println("3.Automovel popular");
											int opcao2 = entrada.nextInt();
											switch(opcao2){
															case 1:
																	System.out.print("Digite a placa do carro: ");
																	entrada.nextLine();
																	String placa = entrada.nextLine();	
																	
																	String tipo = "Grande";
																	
																	System.out.print("Digite o ano do modelo do carro: ");
																	Double ano = entrada.nextDouble();
																	
																	System.out.print("Digite valor base da diaria do carro: ");
																	Double valordiaria = entrada.nextDouble();
																	
																	int vago = 1;
																	
																	Grandes tempGrand = new Grandes(placa, tipo, ano, valordiaria, vago);																	
																	prod.add(tempGrand);																	
																	break;			
															case 2:	
																  	System.out.print("Digite a placa do carro: ");
																  	entrada.nextLine();
																	String placa2 = entrada.nextLine();	
																	
																	String tipo2 = "Medio";
																	
																	System.out.print("Digite o ano do modelo do carro: ");
																	Double ano2 = entrada.nextDouble();
																	
																	System.out.print("Digite valor base da diaria do carro: ");
																	Double valordiaria2 = entrada.nextDouble();
																	
																	int vago2 = 1;
																	
																	Medios tempMed = new Medios(placa2, tipo2, ano2, valordiaria2, vago2);																	
																	prod.add(tempMed);
																	break;
														    case 3:
															    	System.out.print("Digite a placa do carro: ");
															    	entrada.nextLine();
																	String placa3 = entrada.nextLine();	
																	
																	String tipo3 = "Popular";
																	
																	System.out.print("Digite o ano do modelo do carro: ");
																	Double ano3 = entrada.nextDouble();
																	
																	System.out.print("Digite valor base da diaria do carro: ");
																	Double valordiaria3 = entrada.nextDouble();
																	
																	int vago3 = 1;
																	
																	Populares tempPop = new Populares(placa3, tipo3, ano3, valordiaria3, vago3);																	
																	prod.add(tempPop);
																	break;
															}																												    
												
																						
									case 3:
											for(Clientes clientes : client){				
											System.out.println(clientes.toString());}											
											break;												
									case 4:
											for(Automoveis automoveis : prod){				
											System.out.println(automoveis.toString());}									
											break;											
									case 5:		
											System.out.print("Digite o seu CPF: ");
									    	entrada.nextLine();
											String cpf2 = entrada.nextLine();	
											
											System.out.print("Digite o numero de dias que deseja alugar o carro: ");
											String dias = entrada.nextLine();
											
											for(Automoveis automoveis : prod){
												    cont++;  
												    //falta usar calendar para calcular o desconto no valor da diaria
												   //Calendar.getInstance()
													if(1 == automoveis.getVago()){
													System.out.println(automoveis.toString() + "Placa: " + automoveis.getPlaca() + "   Tipo: " + automoveis.getTipo() + "   Ano do modelo: " + automoveis.getAno() + "   Valor da diaria: " + automoveis.getValordiaria()); 
													}																		
											}
										
											break;											
									case 6:		
											
											break;		
								}
				
					System.out.println("1.Cadastrar Cliente");		
					System.out.println("2.Cadastrar Autom�vel");	
					System.out.println("3.Apresentar Clientes cadastrados");	
					System.out.println("4.Apresentar Automoveis cadastrados");
					System.out.println("5.Alugar um autom�vel");	
					System.out.println("6.Devolver um autom�vel informando a data da devolu��o");	
					System.out.println("7.Sair");
					opcao = entrada.nextInt();		

				}	
	}	
}