package visualizacao;

import java.util.ArrayList;
import java.util.Scanner;
import automoveis.Grandes;
import automoveis.Medios;
import automoveis.Populares;
import automoveis.Automoveis;	
	
public class Interface{
	
	int cont = 0;
	public ArrayList<Automoveis>  prod = new ArrayList<Automoveis>();
	public int proximoLivre = 0;
	
	Scanner entrada = new Scanner(System.in);
	
	public void menuPrincipal(){
									System.out.println("0.Cadastrar Cliente");	
									System.out.println("1.Cadastrar Autom�vel");
									System.out.println("2.Apresentar Clientes cadastrados");
									System.out.println("3.Alugar um autom�vel");
									System.out.println("4.Ver todos os produtos cadastrados abaixo de um valor");	
									System.out.println("5.Devolver um autom�vel informando a data da devolu��o");
									System.out.println("6.Sair");
		
										
		int opcao = entrada.nextInt();
		
										while(opcao != 0){	
															switch(opcao){
															case 1:
																System.out.print("Digite o nome do cliente: ");	
																entrada.nextLine();	
																String nome = entrada.nextLine();	
																System.out.print("Digite o cpf do cliente: ");	
																String cpf = entrada.nextLine();																
																
																break;
															
															case 2:
																System.out.print("Digite o cpf do cliente: ");
																String placa = entrada.nextLine();
																//Cadastrar Autom�vel (placa, tipo, ano do modelo e valor base da di�ria)
																		
																break;
															
															case 3:
																	
																	
																
																break;	
																
															case 4:
																
																
																break;	
															}
											
											System.out.println("0.Cadastrar Cliente");		
											System.out.println("1.Cadastrar Autom�vel");	
											System.out.println("2.Apresentar Clientes cadastrados");	
											System.out.println("3.Alugar um autom�vel");	
											System.out.println("4.Ver todos os produtos cadastrados abaixo de um valor");		
											System.out.println("5.Devolver um autom�vel informando a data da devolu��o");	
											System.out.println("6.Sair");	
											opcao = entrada.nextInt();		
			
		}
																															
	
	}	
}