package automoveis;

public class Automoveis {
	
	private String placa;
	private double ano;
	private double valordiaria;

	public Automoveis(String placa, double ano, double valordiaria)
	{
		this.setPlaca(placa) ;
		this.setAno(ano) ;
		this.setValordiaria(valordiaria) ;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public double getAno() {
		return ano;
	}

	public void setAno(double ano) {
		this.ano = ano;
	}
	
	public double getValordiaria() {
		return valordiaria;
	}

	public void setValordiaria(double valordiaria) {
		this.valordiaria = valordiaria;
	}


	
	
	
	
}
