package automoveis;

public class Automoveis {
	
	protected String placa;
	protected String tipo;
	protected double ano;
	protected double valordiaria;
	protected int vago;
	
	public Automoveis(String placa, String tipo, double ano, double valordiaria, int vago)
	{
		this.placa = placa;
		this.tipo = tipo;
		this.ano = ano;
		this.valordiaria = valordiaria;
		this.vago = vago;
	}
	
	/*
	public int carroVago(){
		return vago;
	} */
	
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	
	
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	
	public double getAno() {
		return ano;
	}
	public void setAno(double ano) {
		this.ano = ano;
	}
	
	
	
	public double getValordiaria() {
		return valordiaria;
	}
	public void setValordiaria(double valordiaria) {
		this.valordiaria = valordiaria;
	}

	public int  getVago() {
		return vago;
	}
	public void setVago(int vago) {
		this.vago = vago; 
	}
	
	
	public String toString()
	{
			return "";	//da para testar o armazenamento da string por aqui
	}
	
	
}
