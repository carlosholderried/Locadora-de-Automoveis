package automoveis;

public class Automoveis {
	
	protected String placa;
	protected String tipo;
	protected double ano;	
	protected double valordiaria;
	protected int vago;
	protected String devolucao; 
	
	public Automoveis(String placa, String tipo, double ano, double valordiaria, int vago, String devolucao)
	{
		this.placa = placa;
		this.tipo = tipo;
		this.ano = ano;
		this.valordiaria = valordiaria;
		this.vago = vago;
		this.devolucao = devolucao;
	}
	
	/*
	public int carroVago(){
		return vago;
	} */
	
	public String getPlaca() {		
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	
	public double getAno() {		
		return ano;
	}
	public void setAno(double ano) {
		this.ano = ano;
	}
	
	
	
	public double getValordiaria() {
		return valordiaria;
	}
	public void setValordiaria(double valordiaria) {
		this.valordiaria = valordiaria;
	}

	public int  getVago() {
		return vago;
	}
	public void setVago(int vago) {
		this.vago = vago; 
	}
	
	public String getDevolucao() {
		return tipo;
	}
	public void setDevolucao(String devolucao) {
		this.devolucao = devolucao;
	}
	
	
	public String toString()
	{
			return "Placa: " + placa + " Tipo: " + tipo + " Ano: " + ano + " Valor da diaria: " + valordiaria;	//da para testar o armazenamento da string por aqui
	}
	
	
}
