package automoveis;

public class Populares extends Automoveis{

}
