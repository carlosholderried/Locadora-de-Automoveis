package automoveis;

public class Populares extends Automoveis{

	public Populares(String placa, double ano, double valordiaria) {
		super(placa, ano, valordiaria);
		// TODO Auto-generated constructor stub
	}

}
