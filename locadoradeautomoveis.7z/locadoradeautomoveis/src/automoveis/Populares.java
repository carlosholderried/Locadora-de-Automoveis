package automoveis;

public class Populares extends Automoveis{

	public Populares(String placa, String tipo, double ano, double valordiaria, int vago, String devolucao) {
		super(placa, tipo, ano, valordiaria, vago, devolucao);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
}
