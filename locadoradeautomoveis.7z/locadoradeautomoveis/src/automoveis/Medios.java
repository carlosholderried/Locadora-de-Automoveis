package automoveis;

public class Medios extends Automoveis{

	public Medios(String placa, String tipo, double ano, double valordiaria, int vago) {
		super(placa, tipo, ano, valordiaria, vago);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString()
	{
		return super.toString() + "";							
	}
	
}
