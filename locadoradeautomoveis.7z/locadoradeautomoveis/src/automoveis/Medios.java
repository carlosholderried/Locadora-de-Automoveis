package automoveis;

public class Medios extends Automoveis{

	public Medios(String placa, double ano, double valordiaria) {
		super(placa, ano, valordiaria);
		// TODO Auto-generated constructor stub
	}

}
