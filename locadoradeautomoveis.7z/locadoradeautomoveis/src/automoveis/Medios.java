package automoveis;

public class Medios extends Automoveis{

}
