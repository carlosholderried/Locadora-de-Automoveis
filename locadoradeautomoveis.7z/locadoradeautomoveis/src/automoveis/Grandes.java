package automoveis;

public class Grandes extends Automoveis{

	public Grandes(String placa, double ano, double valordiaria) {
		super(placa, ano, valordiaria);
		// TODO Auto-generated constructor stub
	}

	
}
