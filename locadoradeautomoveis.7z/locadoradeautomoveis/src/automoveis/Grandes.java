package automoveis;

public class Grandes extends Automoveis{

	
}
